package com.backend.proyectoclinicaodontologica.service.impl;

import com.backend.proyectoclinicaodontologica.dto.input.TurnoDtoInput;
import com.backend.proyectoclinicaodontologica.dto.output.TurnoDtoOut;
import com.backend.proyectoclinicaodontologica.entity.Turno;
import com.backend.proyectoclinicaodontologica.exception.ResourceNotFoundException;
import com.backend.proyectoclinicaodontologica.repository.TurnoRepository;
import com.backend.proyectoclinicaodontologica.service.IOdontologoService;
import com.backend.proyectoclinicaodontologica.service.IPacienteService;
import com.backend.proyectoclinicaodontologica.service.ITurnoService;
import com.backend.proyectoclinicaodontologica.utils.JsonPrinter;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TurnoService implements ITurnoService {

    private final Logger LOGGER = LoggerFactory.getLogger(PacienteService.class);

    private TurnoRepository turnoRepository;
    private PacienteService pacienteService;
    private IOdontologoService odontologoService;
    private ModelMapper modelMapper;


    public TurnoService(TurnoRepository turnoRepository, PacienteService pacienteService, OdontologoService odontologoService, ModelMapper modelMapper) {
        this.turnoRepository = turnoRepository;
        this.pacienteService = pacienteService;
        this.odontologoService = odontologoService;
        this.modelMapper = modelMapper;
        configureMapping();
    }

    @Override
    public TurnoDtoOut registrarTurno(TurnoDtoInput turnoDtoInput) {

        //Odontologo odontologoEncontrado = odontologoService.
        Turno turnoRecibido = modelMapper.map(turnoDtoInput,Turno.class);
        if(pacienteService.getPacienteRepository().findByDni(turnoRecibido.getPaciente().getDni())!=null){
            
        }

        LOGGER.info("turnoDtoInput --> {}", JsonPrinter.toString(turnoDtoInput));
        Turno tunoARegistrar = modelMapper.map(turnoDtoInput, Turno.class);
        Turno turnoRegistrado = turnoRepository.save(tunoARegistrar);
        LOGGER.info("TurnoRegistrado --> {}", JsonPrinter.toString(turnoRegistrado));

        TurnoDtoOut turnoDtoOut = modelMapper.map(turnoRegistrado, TurnoDtoOut.class);
        LOGGER.info("TurnoDtoOut --> {}", JsonPrinter.toString(turnoDtoOut));

        return turnoDtoOut;


    }

    @Override
    public TurnoDtoOut buscarTurno(Long id) {

        Turno tunoEncontrado = turnoRepository.findById(id).orElse(null);
        LOGGER.info("pacienteEncontrado -->{}", JsonPrinter.toString(tunoEncontrado));

        TurnoDtoOut turnoDtoOut = null;
        if (tunoEncontrado != null) {
            turnoDtoOut = modelMapper.map(tunoEncontrado, TurnoDtoOut.class);
            LOGGER.info("TurnoDtoOut --> {}", JsonPrinter.toString(turnoDtoOut));

        } else {
            LOGGER.info("Turno no encontrado, verificar el id --> {}", id);

        }

        return turnoDtoOut;
    }

    @Override
    public List<TurnoDtoOut> listarTurnos() {
        List<TurnoDtoOut> turnos = turnoRepository.findAll().stream()
                .map(turno -> modelMapper.map(turno, TurnoDtoOut.class)).collect(Collectors.toList());
        LOGGER.info("Listado de todos los turnos: {}", JsonPrinter.toString(turnos));
        return turnos;
    }

    @Override
    public TurnoDtoOut actualizarTurno(TurnoDtoInput turnoDtoInput, Long id) {
        LOGGER.info("turnoDtoInput --> {}", turnoDtoInput);
        LOGGER.info("id input --> {}", id);

        TurnoDtoOut turnoDtoOut = null;
        Turno turnoEncontrado = turnoRepository.findById(id).orElse(null);

        if (turnoEncontrado != null) {
            Turno turnoAActualizar = modelMapper.map(turnoDtoInput, Turno.class);
            turnoAActualizar.setId(turnoEncontrado.getId());

            Turno turnoActualizado = turnoRepository.save(turnoAActualizar);
            LOGGER.info("Turno actualizado --> {}", JsonPrinter.toString(turnoActualizado));

            turnoDtoOut = modelMapper.map(turnoActualizado, TurnoDtoOut.class);
            LOGGER.info("TurnoDtoOut --> {}", JsonPrinter.toString(turnoDtoOut));

        } else {
            LOGGER.error("No fue posible actualizar el turno porque no se encuentra en nuestra base de datos verificar id {}", id);
            //lanzar excepcion
        }

        return turnoDtoOut;
    }

    @Override
    public void eliminarTurno(Long id) throws ResourceNotFoundException {
        if (buscarTurno(id) != null) {
            turnoRepository.deleteById(id);
            LOGGER.info("Turno eliminado con id -->{}", id);
        } else {
            //lanzar excepcion personalizada
            throw new ResourceNotFoundException("No existe registro de turno con id " + id);

        }
    }


    private void configureMapping() {
        modelMapper.typeMap(TurnoDtoInput.class, Turno.class)
                .addMappings(mapper -> mapper.map(TurnoDtoInput::getOdontologoDtoInput, Turno::setOdontologo));
        modelMapper.typeMap(Turno.class, TurnoDtoOut.class)
                .addMappings(mapper -> mapper.map(Turno::getOdontologo, TurnoDtoOut::setOdontologoDtoOut));

        modelMapper.typeMap(TurnoDtoInput.class, Turno.class)
                .addMappings(mapper -> mapper.map(TurnoDtoInput::getPacienteDtoInput, Turno::setPaciente));
        modelMapper.typeMap(Turno.class, TurnoDtoOut.class)
                .addMappings(mapper -> mapper.map(Turno::getPaciente, TurnoDtoOut::setPacienteDtoOut));
    }

}

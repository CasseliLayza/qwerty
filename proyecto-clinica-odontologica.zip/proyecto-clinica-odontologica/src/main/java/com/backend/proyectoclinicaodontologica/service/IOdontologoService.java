package com.backend.proyectoclinicaodontologica.service;

import com.backend.proyectoclinicaodontologica.dto.input.OdontologoDtoInput;
import com.backend.proyectoclinicaodontologica.dto.output.OdontologoDtoOut;
import com.backend.proyectoclinicaodontologica.exception.ResourceNotFoundException;

import java.util.List;

public interface IOdontologoService {
    OdontologoDtoOut registrarOdontologo(OdontologoDtoInput odontologoDtoInput);

    OdontologoDtoOut buscarOdontologo(Long id);

    List<OdontologoDtoOut> listarOdontologos();

    OdontologoDtoOut actualizarOdontologo(OdontologoDtoInput odontologoDtoInput, Long id);

    void eliminarOdontologo(Long id) throws ResourceNotFoundException;


}

package com.backend.proyectoclinicaodontologica.repository;

import com.backend.proyectoclinicaodontologica.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TurnoRepository extends JpaRepository<Turno, Long> {
    void deleteByOdontologoId(Long odontologoId);
    void deleteByPacienteId(Long pacienteId);
}

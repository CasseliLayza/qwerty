package com.backend.proyectoclinicaodontologica.repository;

import java.util.List;

public interface IDao<T> {
    T registrar(T t);

    T buscarPorId(Long id);

    List<T> listarTodos();

    T actualizar(T t, Long id);

    void eliminar(Long id);

}

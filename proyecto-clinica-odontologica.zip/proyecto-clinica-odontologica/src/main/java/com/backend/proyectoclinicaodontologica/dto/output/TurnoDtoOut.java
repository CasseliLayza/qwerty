package com.backend.proyectoclinicaodontologica.dto.output;

import java.time.LocalDateTime;

public class TurnoDtoOut {

    private Long id;
    private LocalDateTime fechaYHora;
    private OdontologoDtoOut odontologoDtoOut;
    private PacienteDtoOut pacienteDtoOut;


    public TurnoDtoOut() {
    }

    public TurnoDtoOut(Long id, LocalDateTime fechaYHora, OdontologoDtoOut odontologoDtoOut, PacienteDtoOut pacienteDtoOut) {
        this.id = id;
        this.fechaYHora = fechaYHora;
        this.odontologoDtoOut = odontologoDtoOut;
        this.pacienteDtoOut = pacienteDtoOut;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFechaYHora() {
        return fechaYHora;
    }

    public void setFechaYHora(LocalDateTime fechaYHora) {
        this.fechaYHora = fechaYHora;
    }

    public OdontologoDtoOut getOdontologoDtoOut() {
        return odontologoDtoOut;
    }

    public void setOdontologoDtoOut(OdontologoDtoOut odontologoDtoOut) {
        this.odontologoDtoOut = odontologoDtoOut;
    }

    public PacienteDtoOut getPacienteDtoOut() {
        return pacienteDtoOut;
    }

    public void setPacienteDtoOut(PacienteDtoOut pacienteDtoOut) {
        this.pacienteDtoOut = pacienteDtoOut;
    }
}
